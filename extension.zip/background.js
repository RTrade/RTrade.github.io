chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "forceClose") {
        if (sender.tab) {
            chrome.tabs.remove(sender.tab.id, () => {});
        }
    }
});