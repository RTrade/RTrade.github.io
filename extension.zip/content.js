(function () {
    let removeAttempts = 0;
    // Function to remove all canvas elements
    function removeCanvases() {
        const canvasElements = document.querySelectorAll("canvas"); // Fetch all canvas elements.
        if (canvasElements.length === 0) {
            return; // Exit if no canvas elements are found
        }
        canvasElements.forEach(canvas => {
            canvas.remove(); // Remove all canvas elements.
        });
        removeAttempts++;
        if (removeAttempts >= 10) {
            chrome.runtime.sendMessage({action: "forceClose"}); // If canvases keep being created after 10 attempts, close the tab.
        }
    }
	
	setInterval(removeCanvases, 1)
})();